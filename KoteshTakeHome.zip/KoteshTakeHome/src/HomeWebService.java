import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

public class HomeWebService {
	public static final String JSON_PATH = "input.json";

	/**
	 * 
	 * no parameter required
	 * Assumption: input.json file with JSON Array on class path is required to run this program
	 * GSON.jar file is required in classpath
	 * Home and Address classes used to load JSON data into JAVA objects
	 * 
	 */
	public static void main(String[] args) {
		Gson gson = new Gson(); 
		//Service url
		String reqUrl = "http://webservice-takehome-1.spookle.xyz/property?property_id=";
		BufferedReader br;
		Gson g = new Gson();
		try {
			//Read from file
			br = new BufferedReader(new FileReader(JSON_PATH));
			JsonParser parser = new JsonParser();
			//Get Json Array from the reader
			JsonArray jArray = parser.parse(br).getAsJsonArray();
			//used to get highest value of the property
			long homeVal = 0;
			//home owner of highest valued property
			String homeOwner = "";
			//eecute only if Json Array have values
			if (jArray != null) {
				String homeId = "";
			   for (int i=0;i<jArray.size();i++){
				   String jsonString = "";
				   homeId = jArray.get(i).getAsString();
				   //Initiate the url object to get data from service
				   URL url = new URL(reqUrl+ homeId);
				   HttpURLConnection conn = (HttpURLConnection)url.openConnection(); 
				   conn.setRequestMethod("GET");
				   conn.connect();
				   //read the response code from the connection
				   int responsecode = conn.getResponseCode();
				   //check the service availability
				   if(responsecode != 200)
					   System.out.println("Service unavailable");
				   else
				   {
					   //used scanner to read stream from result from service
					   Scanner sc = new Scanner(url.openStream());
					   
					   while(sc.hasNext())
						   jsonString += sc.nextLine();	
					   
					   //if invalid homeId is passes show this message with home id
					   if(jsonString.contains("Property not found")) {
						   System.out.println(homeId + "-Property not found");
					   } else {
						   //Convert the result to Home object using GSON API
						   Home home = g.fromJson(jsonString, Home.class);
						   //Only for VA properties
						   if(home.getAddress().getState().equalsIgnoreCase("VA")) {
							   //Get highest valued property and capture the owner
							   if(homeVal < home.getValue()) {
								   homeVal = home.getValue();
								   homeOwner = home.getOwner();
							   }
						   }
					   }
					   //Close the scanner
					   sc.close();
				   }
			   }
			   //Owner of the highest valued property
			   System.out.println(homeOwner);
			} 
		} catch (MalformedURLException mfurl) { 
			System.out.println("Invalid URL " + mfurl.getMessage());
		} catch (FileNotFoundException fnf) {
			System.out.println("Invalid file path " + fnf.getMessage());
		} catch (IOException ioe) { 
			System.out.println("Cannot read from the file " + ioe.getMessage());
		}
	}
}
/**
 * Bean to load data from json result
 */
class Home {
    private String homeId;
    private Address address;
    private String owner;
    private long value;
    
	public String getHomeId() {
		return homeId;
	}
	public void setHomeId(String homeId) {
		this.homeId = homeId;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public long getValue() {
		return value;
	}
	public void setValue(long value) {
		this.value = value;
	}
}
/**
 * Child object for Home 
 */
class Address {
	private String city;
	private String state;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}